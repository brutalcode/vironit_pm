<div class="form-group ">
<form id="<?php print $search_tapi['id']; ?>" class="search_mini" charset="UTF-8" method="post" action="<?php print $search_tapi['action']; ?>">

        <input type="text" class="form-control nav-input-search" size="20" id="<?php print $search_tapi['search_id']; ?>" name="<?php print $search_tapi['search_name'] ?>" placeholder="Search through site" />

        <span class="input-icon fui-search"></span>
</form>
</div>
