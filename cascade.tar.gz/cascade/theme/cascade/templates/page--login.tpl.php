<div class="list-group side-menu ">
    <?php if($user_tapi['lockscreen']['visiable']) : ?>
    <a class="list-group-item" href="#lock-screen">Lock Screen</a>
    <?php endif; ?>
    <a class="list-group-item" href="#login">Login</a>
    <a class="list-group-item" href="#register">Register</a>
    <a class="list-group-item" href="#forgot-password">Forgot Password?</a>
</div>
<div id="message" class="row message-login">
    <div class="col-md-6 col-md-offset-3 text-center">
            <?php print $messages; ?>
    </div>
</div>

<?php if($user_tapi['lockscreen']['visiable']) : ?>
<section id="lock-screen">
    <div class="row ">
        <div class="login-holder col-md-6 col-md-offset-3 text-center">
            <h2 class="page-header text-center text-primary"> Screen Locked </h2>
            <form role="form" action="index.html" method="post">
                <img src="<?php print $user_tapi['avatar'];?>" alt="" class="user-avatar" />
                <h5>Logging in as <strong class="text-success">vijay kumar</strong></h5>
                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password">
                </div>
                <div class="form-footer text-info">

                    Not You? , <a class="" href="#login">Click here to Login as different User</a>

                    <button type="submit" class="btn btn-info pull-right btn-submit">Login</button>
                </div>

            </form>
        </div>
    </div>
</section>
<?php endif; ?>
<section id="login">
    <div class="row animated fadeILeftBig">
        <div class="login-holder col-md-6 col-md-offset-3">
            <h2 class="page-header text-center text-primary"> Login  </h2>
            <form role="form" id="<?php print $user_tapi['login_form']['login_form_ID'];?>" action="<?php print $user_tapi['login_form']['login_action']; ?>" method="post">
                <div class="form-group">
                    <input type="text" class="form-control" id="edit-name" name="name" placeholder="Enter username">
                </div>
                <div class="form-group">
                    <input type="password" id="edit-pass" name="pass" class="form-control" placeholder="Password">
                </div>
                <div class="form-footer">
                    <label>
                        <input type="checkbox" class="hidden" id="input-checkbox" value="0" >  <i class="fa fa-check-square-o input-checkbox fa-square-o"></i> Remember me?
                    </label>
                    <label>
                        <input type="checkbox" class="hidden" id="input-checkbox" value="0" >  <i class="fa fa-check-square-o input-checkbox fa-square-o"></i> Forgot Password?
                    </label>
                    <button type="submit" id="edit-submit" class="btn btn-info pull-right btn-submit" name="op">Login</button>
                </div>
                <?php echo $user_tapi['login_form']['form_build_id'];?>
                <?php echo $user_tapi['login_form']['login_form_id'];?>
            </form>
        </div>
    </div>
</section>
<section id="register">
    <div class="row animated fadeILeftBig">
        <div class="login-holder col-md-6 col-md-offset-3">
            <h2 class="page-header text-center text-primary"> New User Registration </h2>
            <form role="form" id="<?php print $user_tapi['registration']['register_form_ID'];?>" action="<?php print $user_tapi['registration']['register_action'];?>" method="post">
<!--                <div class="form-group">-->
<!--                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Full Name">-->
<!--                </div>-->
                <div class="form-group">
                    <input type="email"  id="edit-mail" class="form-control" id="exampleInputEmail1" placeholder="Enter email" name="mail">
                </div>
                <div class="form-group">
                    <input id="edit-name" type="text" name="name" class="form-control"  placeholder="Enter username">
                </div>
<!--                <div class="form-group">-->
<!--                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">-->
<!--                </div>-->
                <div class="form-footer">
<!--                    <label>-->
<!--                        <input type="checkbox" class="hidden" id="input-checkbox" value="0" >  <i class="fa fa-check-square-o input-checkbox fa-square-o"></i> I agree to the Terms &amp; Conditions-->
<!--                    </label>-->
                    <button type="submit" id="edit-submit" name="op" class="btn btn-info pull-right btn-submit">Register</button>
                </div>
                <?php echo $user_tapi['registration']['form_build_id'];?>
                <?php echo $user_tapi['registration']['register_form_id'];?>
            </form>
        </div>
    </div>
</section>
<section id="forgot-password">
    <div class="row animated fadeILeftBig">
        <div class="login-holder col-md-6 col-md-offset-3">
            <h2 class="page-header text-center text-primary"> Request New Password </h2>
            <form role="form" id="<?php print $user_tapi['password']['pass_form_ID'] ?>" action="/user/password" method="post">
                <div class="form-group">
                    <input type="email" id="edit-name" name="name" class="form-control" id="exampleInputEmail1" placeholder="Enter Email">
                </div>
                <?php print $user_tapi['password']['form_build_id'];?>
                <?php print $user_tapi['password']['pass_form_id'];?>
                <div class="form-footer">

                    <button type="submit" id="edit-submit" type="submit" name="op" class="btn btn-info pull-right btn-submit">Send Instructions</button>
                </div>
            </form>
        </div>
    </div>
</section>