<div class="row">
    <div class="col-md-6 col-md-offset-3 widget-holder text-white">
                <i class="fa fa-chain-broken text-warning fa-5"></i>
        <?php if (!empty($tabs)): ?>
            <?php print render($tabs); ?>
        <?php endif; ?>
        <?php if (!empty($page['help'])): ?>
            <?php print render($page['help']); ?>
        <?php endif; ?>
        <?php if (!empty($action_links)): ?>
            <ul class="action-links"><?php print render($action_links); ?></ul>
        <?php endif; ?>
        <?php print render($page['content']); ?>

        <?php print render($page['error_page']); ?>

<!--        <i class="fa fa-chain-broken text-warning fa-5"></i>-->
<!--        <h1 class="page-header"> <label class="label">404</label>  Page Not Found</h1>-->
<!--        <p>	Sorry, the page you are looking for is not available. Maybe you want to perform a search?</p>-->
<!--        <div class="form-group ">-->
<!--            <input type="text" class="form-control nav-input-search"  placeholder="Search through site" />-->
<!--            <span class="input-icon fui-search"></span>-->
<!--        </div>-->

    </div>
</div>




