<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN"
  "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">
<html lang="<?php print $language->language; ?>" dir="<?php print $language->dir; ?>"<?php print $rdf_namespaces;?>>
<head profile="<?php print $grddl_profile; ?>">
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php print $head; ?>
  <title><?php print $head_title; ?></title>
  <?php print $styles; ?>
  <?php print $scripts; ?>

    <!-- Loading Custom Stylesheets -->
    <?php print '<link href="'.base_path().path_to_theme().'/css/custom.css" rel="stylesheet">';?>

    <?php print '<link href="'.base_path().path_to_theme().'/images/favicon.ico" rel="shortcut icon" >';?>

    <!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
    <!--[if lt IE 9]>
   <?php print '<script src="'.base_path().path_to_theme().'/js/html5shiv.js"></script>'."\n";?>
    <![endif]-->
</head>
<body class="<?php print $classes; ?>" <?php print $attributes;?>>
  <?php print $page_top; ?>
    <?php print $page; ?>
  <?php print $page_bottom; ?>
</body>
</html>
