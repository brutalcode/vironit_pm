
<form id="<?php print $search_tapi['id']; ?>" charset="UTF-8" class="search_mini" method="post" action="<?php print $search_tapi['action']; ?>">

        <input type="text" class="form-control form-cascade-control nav-input-search" size="20" id="<?php print $search_tapi['search_id']; ?>" name="<?php print $search_tapi['search_name']; ?>" placeholder="Search through site" />

        <span class="input-icon fui-search"></span>
</form>

