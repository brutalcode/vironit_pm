<?php
/**
 * @file
 * Template file for Theme Cascade
 */
include_once dirname(__FILE__).'/includes/widgets_js.inc';
include_once dirname(__FILE__).'/includes/template_api.inc';

function cascade_preprocess_html(&$variables) {
    $reqUrl = $_GET['q'];
    global $user;
    if(preg_match ('/user/', $reqUrl) && !$variables['logged_in']){
        //none authenticated user accessing login page
        _login_css();
        _login_js();
        $variables['theme_hook_suggestions'][] = 'html__login';
    }else{
        _default_css();
        _default_js();
        if ((arg(0) == 'node') && is_numeric(arg(1)) && ($node = node_load(arg(1)))) {
        switch($node->type){
            case 'dashboard':
                _load_dashboard_js();
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/dashboard-custom.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'calendar':
                _load_calendar_js();
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'chat':
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/chat.js', array('scope' =>'footer', 'type' => 'file'));
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'inbox':
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/mail-custom.js', array('scope' =>'footer', 'type' => 'file'));
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'gallery':
                _load_gallery_js();
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'animations':
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/animate-custom.js', array('scope' =>'footer', 'type' => 'file'));
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'notification':
                _load_notifications_js();
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'slider':
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/sliders-custom.js', array('scope' =>'footer', 'type' => 'file'));
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'info_boxes':
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/charts/jquery.sparkline.min.js', array('scope' =>'footer', 'type' => 'file'));
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/info-boxes.js', array('scope' =>'footer', 'type' => 'file'));
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'tooltips_popovers':
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/tooltips-popovers.js', array('scope' =>'footer', 'type' => 'file'));
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'draggable_portlets':
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/inettuts.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'boot_box':
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootbox.js', array('scope' =>'footer', 'type' => 'file'));
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootbox-custom.js', array('scope' =>'footer', 'type' => 'file'));
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'extended_modals':
                drupal_add_css(drupal_get_path('theme',$GLOBALS['theme']) .'/css/bootstrap-modal-bs3fix.css', array('type' => 'file', 'weight' =>CSS_THEME,'preprocess' => FALSE));
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-modalmanager.js', array('scope' =>'footer', 'type' => 'file'));
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-modal.js', array('scope' =>'footer', 'type' => 'file'));
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-modal-custom.js', array('scope' =>'footer', 'type' => 'file'));
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'editable_tables':
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-editable.min.js', array('scope' =>'footer', 'type' => 'file'));
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-datetimepicker.min.js', array('scope' =>'footer', 'type' => 'file'));
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-editable-custom.js', array('scope' =>'footer', 'type' => 'file'));
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'dynamic_tables':
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-datatables.js', array('scope' =>'footer', 'type' => 'file'));
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/dataTables-custom.js', array('scope' =>'footer', 'type' => 'file'));
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'file_dropzone':
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.fileupload.js', array('scope' =>'footer', 'type' => 'file'));
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.iframe-transport.js', array('scope' =>'footer', 'type' => 'file'));
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/file-uploads-custom.js', array('scope' =>'footer', 'type' => 'file'));
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.knob.js', array('scope' =>'footer', 'type' => 'file'));
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'input_masks':
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.maskedinput.min.js', array('scope' =>'footer', 'type' => 'file'));
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/input-masks-custom.js', array('scope' =>'footer', 'type' => 'file'));
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'form_validation':
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/validate.js', array('scope' =>'footer', 'type' => 'file'));
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/validation-custom.js', array('scope' =>'footer', 'type' => 'file'));
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'form_wizard':
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.smartWizard.js', array('scope' =>'footer', 'type' => 'file'));
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/smartWizard-custom.js', array('scope' =>'footer', 'type' => 'file'));
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'form_elements_layouts':
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.pulsate.min.js', array('scope' =>'footer', 'type' => 'file'));
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/forms-custom.js', array('scope' =>'footer', 'type' => 'file'));
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'multiple_file_upload':
                _load_multiple_file_upload_js();
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'wysiwyg_editor':
                _load_wysiwyg_js();
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'basic_charts':
                _load_basic_charts_js();
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'live_charts':
                _load_live_charts_js();
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case'morris_charts':
                _load_morris_charts_js();
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case'pie_charts':
                _load_pie_charts_js();
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'sparklines':
                _load_sparklines_js();
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'google_maps':
                _load_google_maps();
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'nvd3_charts':
                _load_nvd3_charts_js();
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'vector_maps':
                _load_vector_maps_js();
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'picker':
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-timepicker-edited.js', array('scope' =>'footer', 'type' => 'file'));
                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-timepicker-custom.js', array('scope' =>'footer', 'type' => 'file'));
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
            case 'error_page':
                $variables['classes_array'] = array();
                drupal_add_css(drupal_get_path('theme',$GLOBALS['theme']) .'/css/404.css', array('type' => 'file', 'weight' =>CSS_THEME + 1,'preprocess' => FALSE));
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                $variables['theme_hook_suggestions'][] = 'html__error';
                break;
            default:
//                drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
                break;
        }
    }

        drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));


        $variables['classes_array'][] = 'cascade';

        $variables['head_tapi'] = _header_tapi($variables);
    }

    //remove classes from body tag
    $variables['classes_array'] = array();
    //making regions available in html scope
    //retrieve context plugin as alternative for managing blocks

    $ctx_plugin = (module_exists('context')) ? context_get_plugin('reaction', 'block') : '' ;
    foreach (system_region_list($GLOBALS['theme']) as $region_key => $region_name) {
        if(block_get_blocks_by_region($region_key)) {
            $blocks = block_get_blocks_by_region($region_key);
        }elseif(!empty($ctx_plugin)){
            $blocks = $ctx_plugin->block_get_blocks_by_region($region_key);
        }
        // Get the content for each region and add it to the $region variable
        $variables['region'][$region_key] = (isset($blocks) && !empty($blocks)) ? $blocks : array();
    }
}

function cascade_preprocess_page(&$variables){
//    $node = $variables['node'];
    $reqUrl = $_GET['q'];


    /*******Page Var******/
    $variables['page_tapi'] = array();
    if(!empty($variables['node'])){
        $node = $variables['node'];
        $title_instance = field_get_items('node', $node, 'field_page_title');
        $page_title_val = (!empty($title_instance[0])) ? field_view_value('node', $node, 'field_page_title', $title_instance[0]) : '';
        $custom_title = htmlspecialchars_decode(render($page_title_val));
        $variables['page_tapi']['title']= (!empty($custom_title)) ? $custom_title : $node->title;
        $info_instance = field_get_items('node', $node, 'field_page_information');
        $info_instance_val = (!empty($info_instance[0])) ? field_view_value('node', $node, 'field_page_information', $info_instance[0]) : '';
        $variables['page_tapi']['intro'] = htmlspecialchars_decode(render($info_instance_val));

        switch($node->type){
            case 'error_page':
                $variables['theme_hook_suggestions'][] = 'page__error_page';
                break;
            case 'timeline':
                $variables['theme_hook_suggestions'][] = 'page__timeline';
                break;
        }

    }else{
        $variables['page_tapi']['title']= (!empty($variables['$title'])) ? $variables['$title'] : '';
        $variables['page_tapi']['intro'] = '';
    }


    /*******User Login, Registration, Password*******/
    if(preg_match ('/user/', $reqUrl) && !$variables['logged_in']){
            $variables['user_tapi'] = _user_tapi();
            $variables['user_tapi']['is_authenticated'] = true;

            $variables['user_login_link'] = url('user');
            $variables['theme_hook_suggestions'][] = 'page__login';

            //Lock Screen
            $lockscreen = array();
            $lockscreen['visiable'] = (theme_get_setting('locksreen_visibility')) ? TRUE : FALSE ;
            $variables['user_tapi']['lockscreen'] = $lockscreen;

            //user reset password
            $password = array();
            $pass_form_name = 'user-pass';
            $password['pass_form_ID'] = $pass_form_name;
            $pass_form = drupal_get_form('user_pass');
            $password['pass_action'] = $pass_form['#action'];
            $password['pass_form_id'] = render($pass_form['form_id']);
            $password['form_build_id'] = render($pass_form['form_build_id']);
            $variables['user_tapi']['password'] = $password;

            //user registration
            $registration = array();
            $register_form_name = 'user_register_form';
            $registration['register_form_ID'] = 'user-register-form';
            $register_form = drupal_get_form($register_form_name);
            $registration['register_action'] = $register_form['#action'];
            $registration['register_form_id'] = render($register_form['form_id']);
            $registration['form_build_id'] = render($register_form['form_build_id']);
            $variables['user_tapi']['registration'] = $registration;

            //links to login, registration and pass reset
//            $login['registration_link'] = url('user/register');
//            $login['reset_pass_link'] = url('user/password');
//            $login['site_name'] = (theme_get_setting('toggle_name') ? check_plain(variable_get('site_name', '')) : '');

            //login form
            $login = array();
            $login_form = drupal_get_form('user_login');
            $login['login_action'] = $login_form['#action'];
            $login['login_form_id'] = render($login_form['form_id']);
            $login['login_form_ID'] = 'user-login';
            $login['form_build_id'] = render($login_form['form_build_id']);
            $variables['user_tapi']['login_form'] = $login;
    }else{
        //for user profile
        $variables['user_tapi'] = _user_tapi();
        $variables['user_tapi']['is_authenticated'] = true;
    }


    /****Breadcrumbs*****/
    $breadcrumb = drupal_get_breadcrumb();
    $pattern = '/<span class=[\\\'"][\s]?badge bg-primary pull-right[\s]?[\\\'"]>[^\<\/span>]*/';
    $breads_len = count($breadcrumb);

    $newBreads[] = l(t('Dashboard'), NULL);
    for($i=1;$i<$breads_len;$i++){
        //remove any html tags or badge numbers
            $strWithoutBadge = preg_replace($pattern, ' ', $breadcrumb[$i]);
            $strWithoutTags = strip_tags($strWithoutBadge , '<a>');
            $newBreads[] = $strWithoutTags;
    }
    drupal_set_breadcrumb($newBreads);

}

function cascade_preprocess_region(&$variables) {
    //@toDo consider not removing all classes
//    unset($variables['classes_array']);
    if($variables['region'] == 'sidebar_first'){
        $variables['classes_array'][] = 'left-sidebar';
    }
//    switch($variables['region']){
//        case 'page_header':
//            $variables['theme_hook_suggestions'][] = 'block__no_wrapper';
//            break;
//        case 'sidebar_first':
//            $variables['classes_array'][] = 'left-sidebar';
//            break;
//    }
}

function cascade_preprocess_block(&$variables) {
    switch($variables['block']->region){
        case 'sidebar_first':
            if($variables['block']->delta !== 'main-menu'){
                //for main menu remove all other classes
                $variables['classes_array'][] = 'block-padding';
            }
            $variables['classes_array'][] = 'sidebar-holder';
            break;
        case 'sidebar_second':
            $variables['classes_array'][] = 'right-sidebar-holder';
            break;
        default:
            break;
    }

    if($variables['block_html_id'] == 'block-search-form' && $variables['block']->region == 'error_page'){
        $variables['search_tapi'] = _search_tapi();
        $variables['theme_hook_suggestions'][] = 'block__search_cascade_error';
    }elseif($variables['block_html_id'] == 'block-search-form' && $variables['block']->region == 'sidebar_first'){
        $variables['search_tapi'] = _search_tapi();
        //use default template file
    }elseif($variables['block_html_id'] == 'block-search-form'){
    $variables['search_tapi'] = _search_tapi();
//        unset($variables['classes_array']);
    $variables['theme_hook_suggestions'][] = 'block__search_cascade';
    }
}


/********Breadcrumbs*******/
/**
 * Overrides theme_breadcrumb().
 *
 * Print breadcrumbs as an ordered list.
 */
function cascade_breadcrumb($variables) {
    $output = '';
    $breadcrumb = $variables['breadcrumb'];
    $bootstrap_breadcrumb = theme_get_setting('bootstrap_breadcrumb');
    if (($bootstrap_breadcrumb == 1 || ($bootstrap_breadcrumb == 2 && arg(0) == 'admin')) && !empty($breadcrumb)) {
        //remove html tags for none rendered items
        foreach($breadcrumb as $key => $item){
            if(is_array($item) && !empty($item['data'])){
                $breadcrumb[$key]['data'] = strip_tags(htmlspecialchars_decode($item['data']));
            }
        }

        $output = theme('item_list', array(
            'attributes' => array(
                'class' => array('breadcrumb'),
            ),
            'items' => $breadcrumb,
            'type' => 'ul',
        ));
    }
    return $output;
}


/*********Menus******/
function cascade_menu_tree(&$variables) {
    $menu = '<ul class="nav nav-list">';
    $menu .= '<li class="nav-toggle">';
    $menu .= '<button class="btn  btn-nav-toggle text-primary"><i class="fa fa-angle-double-left toggle-left"></i> </button>';
    $menu .= '</li>';
    $menu .= $variables['tree'];
    $menu .= '</ul>';
    return $menu;
}

function cascade_menu_tree__user_menu(&$variables){
    return '<ul class="dropdown-menu">'.$variables['tree'].'</ul>';
}

function cascade_menu_link__user_menu(array $variables) {
    global $user;
    $element = $variables['element'];
    $menu_link ='';
    if( $user->uid == 0){
        //for anonymous users
        if($element['#href'] == 'user'){
            $menu_link .= '<li class="divider"></li>';
            $element['#localized_options']['attributes']['class'][] = 'text-danger';
        }
        $output = l($element['#title'], $element['#href'], $element['#localized_options']);
        $menu_link .= '<li' . drupal_attributes($element['#attributes']) . '>' . $output . "</li>\n";
    }else{
        //authenticated user
        if($element['#href'] == 'user/logout'){
            //for logout menu item
            $menu_link .= '<li class="divider"></li>';
            $element['#localized_options']['attributes']['class'][] = 'text-danger';
        }

        if($element['#href'] == 'user' && preg_match ('/Login/', $element['#title'])){
            //don't print 'login' menu item
            $element['#localized_options']['attributes']['class'][] = 'hidden';
        }

        $output = l($element['#title'], $element['#href'], $element['#localized_options']);
        $menu_link .= '<li' . drupal_attributes($element['#attributes']) . '>' . $output . "</li>\n";
    }
    return $menu_link;
}

function cascade_menu_link(array $variables) {
    $element = $variables['element'];
    $sub_menu = '';

    if ($element['#below']) {
        // Prevent dropdown functions from being added to management menu so it
        // does not affect the navbar module.
        if (($element['#original_link']['menu_name'] == 'management') && (module_exists('navbar'))) {
            $sub_menu = drupal_render($element['#below']);
        }
        elseif ((!empty($element['#original_link']['depth'])) && ($element['#original_link']['depth'] == 1)) {
            // Add our own wrapper.
            unset($element['#below']['#theme_wrappers']);
            $sub_menu = '<ul class="open-selected" >' . drupal_render($element['#below']) . '</ul>';
//            $sub_menu = '<ul>' . drupal_render($element['#below']) . '</ul>';
            // Generate as standard dropdown.
//            $element['#title'] .= ' <span class="caret"></span>';
            $element['#attributes']['class'][] = 'submenu';
            $element['#localized_options']['html'] = TRUE;

            // Set dropdown trigger element to # to prevent inadvertant page loading
            // when a submenu link is clicked.
//            $element['#localized_options']['attributes']['data-target'] = '#';
            $element['#localized_options']['attributes']['class'][] = 'dropdown';
//            $element['#localized_options']['attributes']['data-toggle'] = 'dropdown';

            //set the parent to display when child is currently selected

        }
    }

//    $element['#localized_options']['attributes']['data-original-title'] = $element['#title'];
        $element['#localized_options']['attributes']['data-original-title'] = 'Utility';
//    $element['#localized_options']['attributes']['class'][] = 'nav-space';

    // On primary navigation menu, class 'active' is not set on active menu item.
    // @see https://drupal.org/node/1896674
    if (($element['#href'] == $_GET['q'] || ($element['#href'] == '<front>' && drupal_is_front_page())) && (empty($element['#localized_options']['language']))) {
        $element['#attributes']['class'][] = 'active';
    }



//    //set the parent to display when child is currently selected
    if(in_array("active-trail", $element['#attributes']['class'])){
        $element['#attributes']['class'][] = 'active';
    }

    //removing everything but dropdown class
    $sum_menu_class = array('dropdown');
    $element['#localized_options']['attributes']['class'] = (!empty($element['#localized_options']['attributes']['class'])) ? array_intersect($element['#localized_options']['attributes']['class'], $sum_menu_class) : '';

    if(!empty($element['#localized_options']['attributes']['class']) && in_array("dropdown", $element['#localized_options']['attributes']['class'])) {
        $output = '<a href="#" class="dropdown">'.$element['#title'].'</a>';
    } else{
        $output = l($element['#title'], $element['#href'], $element['#localized_options']);
    }
    //    $output = l($element['#title'], $element['#href'], $element['#localized_options']);

    //removing everything except submenu class
    $sum_menu_class = array('submenu', 'active');
    $element['#attributes']['class'] = array_intersect($element['#attributes']['class'], $sum_menu_class);

    return '<li' . drupal_attributes($element['#attributes']) . '>' . $output . $sub_menu . "</li>\n";
//    return '<li' . drupal_attributes($diff_menu_items. '>' . $output . $sub_menu . "</li>\n";

}

/**
 * Overrides theme_menu_local_tasks().
 */
function cascade_menu_local_tasks(&$variables) {
    $output = '';

    if (!empty($variables['primary'])) {
        $variables['primary']['#prefix'] = '<h2 class="element-invisible">' . t('Primary tabs') . '</h2>';
        $variables['primary']['#prefix'] .= '<ul class="tabs--primary nav nav-tabs-cascade">';
        $variables['primary']['#suffix'] = '</ul>';
        $output .= drupal_render($variables['primary']);
    }

    if (!empty($variables['secondary'])) {
        $variables['secondary']['#prefix'] = '<h2 class="element-invisible">' . t('Secondary tabs') . '</h2>';
        $variables['secondary']['#prefix'] .= '<ul class="tabs--secondary pagination pagination-sm">';
        $variables['secondary']['#suffix'] = '</ul>';
        $output .= drupal_render($variables['secondary']);
    }

    return $output;
}


function cascade_js_alter(&$javascript) {
    //use theme specific
    unset($javascript[drupal_get_path('theme','bootstrap').'/js/bootstrap.js']);


    if($jQuery_ver = variable_get('jquery_update_jquery_version', '1.8') === '1.10'){
        //use jquery_updates ui libraries instead the drupal core
        foreach($javascript as $key => $js_path){
            $token_path = explode("/", $key);
            $new_path = drupal_get_path('module','jquery_update').'/replace/ui/ui/minified/'.$token_path[count($token_path) - 1];

            if($token_path[0] === 'misc' && $token_path[1] === 'ui'){
                //avoid duplicates
                if(!array_key_exists($new_path,$js_path)){
                    $data = $javascript[$key];
                    $data['version'] = "1.10.2";
                    $data['data'] = $new_path;
                    unset($javascript[$key]);
                    $javascript[$new_path] = $data;
                }

            }

        }
    }
}
function cascade_css_alter(&$css) {
    //use theme specific
    unset($css[drupal_get_path('theme','bootstrap').'/css/bootstrap.css']);
}


function _login_js(){
//    drupal_add_js('http://code.jquery.com/jquery-1.10.2.min.js', array('scope' =>'footer', 'type' => 'external'));
//    drupal_add_js('http://code.jquery.com/jquery-migrate-1.2.1.min.js', array('scope' =>'footer', 'type' => 'external'));
    drupal_add_js('http://code.jquery.com/jquery-migrate-1.2.1.min.js', array('scope' =>'header', 'group' => JS_LIBRARY - 10, 'type' => 'external'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery-ui-1.10.3.custom.min.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.ui.touch-punch.min.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap.min.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-select.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-switch.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.tagsinput.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.placeholder.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-typeahead.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/application.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/moment.min.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.dataTables.min.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.sortable.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.gritter.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.nicescroll.min.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/skylo.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/prettify.min.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.noty.js', array('scope' =>'footer', 'type' => 'file'));

    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/scroll.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.panelSnap.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/login.js', array('scope' =>'footer', 'type' => 'file'));
}

function _default_js(){
    //production
//    drupal_add_js('http://code.jquery.com/jquery-1.10.2.min.js', array('scope' =>'footer', 'type' => 'external'));
    drupal_add_js('http://code.jquery.com/jquery-migrate-1.2.1.min.js', array('scope' =>'header', 'group' => JS_LIBRARY, 'type' => 'external'));

    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery-ui-1.10.3.custom.min.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/less-1.5.0.min.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.ui.touch-punch.min.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap.min.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-select.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-switch.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.tagsinput.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.placeholder.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-typeahead.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/application.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/moment.min.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.dataTables.min.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.sortable.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.gritter.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.nicescroll.min.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/prettify.min.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.noty.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bic_calendar.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.accordion.js', array('scope' =>'footer', 'type' => 'file'));
//    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/jquery.accordion.source.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/skylo.js', array('scope' =>'footer', 'type' => 'file'));
    //@ToDo implement Theme settings and UI to manage faileSafe banner
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/failsafe.js', array('scope' =>'footer', 'type' => 'file'));

    //@ToDo see if theme-options.js applies
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/theme-options.js', array('scope' =>'footer', 'type' => 'file'));

    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-progressbar.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-progressbar-custom.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-colorpicker.min.js', array('scope' =>'footer', 'type' => 'file'));
    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/bootstrap-colorpicker-custom.js', array('scope' =>'footer', 'type' => 'file'));

////<!-- Core Jquery File  =============================-->
//    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/core.js', array('scope' =>'footer', 'type' => 'file'));
//    drupal_add_js(drupal_get_path('theme',$GLOBALS['theme']) .'/js/dashboard-custom.js', array('scope' =>'footer', 'type' => 'file'));
}

function _login_css(){
    //@ToDo we including boostrap.css and other css manually so it is of type LINK instead of STYLE import something unable to specify from .info file
//    drupal_add_css(drupal_get_path('theme',$GLOBALS['theme']) .'/bootstrap/css/bootstrap.min.css', array('type' => 'file', 'weight' =>CSS_THEME - 1,'preprocess' => FALSE));
    drupal_add_css(drupal_get_path('theme',$GLOBALS['theme']) .'/css/bootstrap.css', array('type' => 'file', 'weight' =>CSS_THEME - 1,'preprocess' => FALSE));

    //rest of the css
    drupal_add_css(drupal_get_path('theme',$GLOBALS['theme']) .'/css/font-awesome.css', array('type' => 'file', 'weight' =>CSS_THEME,'preprocess' => FALSE));
    drupal_add_css(drupal_get_path('theme',$GLOBALS['theme']) .'/css/style.css', array('type' => 'file', 'weight' =>CSS_THEME,'preprocess' => FALSE));
    drupal_add_css(drupal_get_path('theme',$GLOBALS['theme']) .'/css/login.css', array('type' => 'file', 'weight' =>CSS_THEME,'preprocess' => FALSE));
}

function _default_css(){
    //@ToDo we including boostrap.css and other css manually so it is of type LINK instead of STYLE import something unable to specify from .info file
//    drupal_add_css(drupal_get_path('theme',$GLOBALS['theme']) .'/bootstrap/css/bootstrap.min.css', array('type' => 'file', 'weight' =>CSS_THEME - 1,'preprocess' => FALSE));
    drupal_add_css(drupal_get_path('theme',$GLOBALS['theme']) .'/css/bootstrap.css', array('type' => 'file', 'weight' =>CSS_THEME - 1,'preprocess' => FALSE));

    //rest of the css
    drupal_add_css(drupal_get_path('theme',$GLOBALS['theme']) .'/css/font-awesome.css', array('type' => 'file', 'weight' =>CSS_THEME,'preprocess' => FALSE));
    drupal_add_css(drupal_get_path('theme',$GLOBALS['theme']) .'/css/style.css', array('type' => 'file', 'weight' =>CSS_THEME,'preprocess' => FALSE));
}
