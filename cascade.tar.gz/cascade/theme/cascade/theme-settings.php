<?php

/**
 * Implements hook_form_FORM_ID_alter().
 */
function cascade_form_system_theme_settings_alter(&$form, $form_state, $form_id = NULL) {
  // Work-around for a core bug affecting admin themes.
  // @see https://drupal.org/node/943212
  if (isset($form_id)) {
    return;
  }

  _cascade_settings_form($form, $form_state);
}

function _cascade_settings_form(&$form, $form_state) {
    if ((!module_exists('jquery_update') || !version_compare(variable_get('jquery_update_jquery_version', 0), 1.7, '>=')) && !theme_get_setting('bootstrap_toggle_jquery_error')) {
        drupal_set_message(t('jQuery Update is not enabled, Bootstrap requires a minimum jQuery version of 1.7 or higher.<br/>Please enable <a href="https://drupal.org/project/jquery_update">jQuery Update module</a> 7.x-2.3 or higher, you must manually set this in the configuration after it is installed.'), 'error');
    }

    $form['cascade'] = array(
        '#type' => 'vertical_tabs',
        '#attached' => array(
            'js'  => array(drupal_get_path('theme', 'bootstrap') . '/js/bootstrap.admin.js'),
        ),
        '#prefix' => '<h2><small>' . t('Cascade Settings') . '</small></h2>',
        '#weight' => -20,
    );

    // Components.
    $form['lockscreen'] = array(
        '#type' => 'fieldset',
        '#title' => t('Lock Screen'),
        '#group' => 'cascade',
    );

    $form['lockscreen']['options'] = array(
        '#type' => 'fieldset',
        '#title' => t('Visibility'),
        '#collapsible' => TRUE,
        '#collapsed' => TRUE,
    );

    $form['lockscreen']['options']['locksreen_visibility'] = array(
        '#type' => 'select',
        '#title' => t('Lock Screen Visibility'),
        '#default_value' => theme_get_setting('locksreen_visibility'),
        '#options' => array(
            0 => t('Hidden'),
            1 => t('Visible'),
//      2 => t('Only in admin areas'),
        ),
    );

    $form['site_styler'] = array(
        '#type' => 'fieldset',
        '#title' => t('Site Styler'),
        '#group' => 'cascade',
    );
    // Anchors.
    $form['site_styler']['options'] = array(
        '#type' => 'fieldset',
        '#title' => t('Status'),
        '#collapsible' => TRUE,
        '#collapsed' => TRUE,
    );
    $form['site_styler']['options']['styler_status'] = array(
        '#type' => 'select',
        '#title' => t('Site Styler Status'),
        '#default_value' => theme_get_setting('styler_status'),
        '#options' => array(
            1 => t('Enabled'),
            0 => t('Disabled'),
        )
    );

    $form['user_styler'] = array(
        '#type' => 'fieldset',
        '#title' => t('User Styler'),
        '#group' => 'cascade',
    );
    // Anchors.
    $form['user_styler']['options'] = array(
        '#type' => 'fieldset',
        '#title' => t('Options'),
        '#collapsible' => TRUE,
        '#collapsed' => TRUE,
    );
    $form['user_styler']['options']['user_styler_client'] = array(
        '#type' => 'checkbox',
        '#title' => t('Style on every request in user browser'),
        '#default_value' => theme_get_setting('user_styler_client'),
        '#description' => t('The style is generated in user browser on every request (not recommended for performance)'),
    );

    $form['user_styler']['options']['user_styler_server'] = array(
        '#type' => 'checkbox',
        '#title' => t('Style once on server'),
        '#default_value' => theme_get_setting('user_styler_server'),
        '#description' => t('Stylesheet generated once for each user and stored till the end of session (not recommended for cost effectiveness of server)'),
    );
}
